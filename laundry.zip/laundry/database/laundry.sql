-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2017 at 11:30 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `laundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email_id` varchar(75) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `repassword` text NOT NULL,
  `last_login` varchar(100) NOT NULL,
  `ip_add` varchar(100) NOT NULL,
  `login_status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `mobile`, `email_id`, `username`, `password`, `repassword`, `last_login`, `ip_add`, `login_status`) VALUES
(1, 'Laundry Administrator', '8767228990', 'info@redplanetcomputers.com', 'madmin', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `bulk_messge`
--

CREATE TABLE IF NOT EXISTS `bulk_messge` (
  `id` int(11) NOT NULL,
  `protocol` varchar(100) NOT NULL,
  `smtp_host` varchar(100) NOT NULL,
  `smtp_port` varchar(50) NOT NULL,
  `smtp_user` varchar(100) NOT NULL,
  `smtp_pass` varchar(50) NOT NULL,
  `mailtype` varchar(100) NOT NULL,
  `charset` varchar(100) NOT NULL,
  `limit` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bulk_messge`
--

INSERT INTO `bulk_messge` (`id`, `protocol`, `smtp_host`, `smtp_port`, `smtp_user`, `smtp_pass`, `mailtype`, `charset`, `limit`) VALUES
(1, 'smtp', 'ssl://smtp.googlemail.com', '465', 'redplanetbulk@gmail.com', 'demo', 'html', 'utf-8', 10);

-- --------------------------------------------------------

--
-- Table structure for table `cloths`
--

CREATE TABLE IF NOT EXISTS `cloths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cloth_type` varchar(100) NOT NULL,
  `cloth_code` varchar(50) NOT NULL,
  `cloth_image` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cloth_type` (`cloth_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cloths`
--

INSERT INTO `cloths` (`id`, `cloth_type`, `cloth_code`, `cloth_image`) VALUES
(1, 'Shirts', 'SHR', ''),
(2, 'Pants', 'PANT', ''),
(3, 'dress', 'drs', ''),
(4, 'kurta', 'kt', '');

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE IF NOT EXISTS `currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(100) DEFAULT NULL,
  `currency` varchar(100) DEFAULT NULL,
  `code` varchar(25) DEFAULT NULL,
  `currency_symbol` varchar(100) DEFAULT NULL,
  `thousand_separator` varchar(10) DEFAULT NULL,
  `decimal_separator` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=133 ;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `country_name`, `currency`, `code`, `currency_symbol`, `thousand_separator`, `decimal_separator`) VALUES
(1, 'Albania', 'Leke', 'ALL', 'Lek', ',', '.'),
(2, 'America', 'Dollars', 'USD', '$', ',', '.'),
(3, 'Afghanistan', 'Afghanis', 'AF', '؋', ',', '.'),
(4, 'Argentina', 'Pesos', 'ARS', '$', ',', '.'),
(5, 'Aruba', 'Guilders', 'AWG', 'ƒ', ',', '.'),
(6, 'Australia', 'Dollars', 'AUD', '$', ',', '.'),
(7, 'Azerbaijan', 'New Manats', 'AZ', 'ман', ',', '.'),
(8, 'Bahamas', 'Dollars', 'BSD', '$', ',', '.'),
(9, 'Barbados', 'Dollars', 'BBD', '$', ',', '.'),
(10, 'Belarus', 'Rubles', 'BYR', 'p.', ',', '.'),
(11, 'Belgium', 'Euro', 'EUR', '€', ',', '.'),
(12, 'Beliz', 'Dollars', 'BZD', 'BZ$', ',', '.'),
(13, 'Bermuda', 'Dollars', 'BMD', '$', ',', '.'),
(14, 'Bolivia', 'Bolivianos', 'BOB', '$b', ',', '.'),
(15, 'Bosnia and Herzegovina', 'Convertible Marka', 'BAM', 'KM', ',', '.'),
(16, 'Botswana', 'Pula''s', 'BWP', 'P', ',', '.'),
(17, 'Bulgaria', 'Leva', 'BG', 'лв', ',', '.'),
(18, 'Brazil', 'Reais', 'BRL', 'R$', ',', '.'),
(19, 'Britain (United Kingdom)', 'Pounds', 'GBP', '£', ',', '.'),
(20, 'Brunei Darussalam', 'Dollars', 'BND', '$', ',', '.'),
(21, 'Cambodia', 'Riels', 'KHR', '៛', ',', '.'),
(22, 'Canada', 'Dollars', 'CAD', '$', ',', '.'),
(23, 'Cayman Islands', 'Dollars', 'KYD', '$', ',', '.'),
(24, 'Chile', 'Pesos', 'CLP', '$', ',', '.'),
(25, 'China', 'Yuan Renminbi', 'CNY', '¥', ',', '.'),
(26, 'Colombia', 'Pesos', 'COP', '$', ',', '.'),
(27, 'Costa Rica', 'Colón', 'CRC', '₡', ',', '.'),
(28, 'Croatia', 'Kuna', 'HRK', 'kn', ',', '.'),
(29, 'Cuba', 'Pesos', 'CUP', '₱', ',', '.'),
(30, 'Cyprus', 'Euro', 'EUR', '€', ',', '.'),
(31, 'Czech Republic', 'Koruny', 'CZK', 'Kč', ',', '.'),
(32, 'Denmark', 'Kroner', 'DKK', 'kr', ',', '.'),
(33, 'Dominican Republic', 'Pesos', 'DOP ', 'RD$', ',', '.'),
(34, 'East Caribbean', 'Dollars', 'XCD', '$', ',', '.'),
(35, 'Egypt', 'Pounds', 'EGP', '£', ',', '.'),
(36, 'El Salvador', 'Colones', 'SVC', '$', ',', '.'),
(37, 'England (United Kingdom)', 'Pounds', 'GBP', '£', ',', '.'),
(38, 'Euro', 'Euro', 'EUR', '€', ',', '.'),
(39, 'Falkland Islands', 'Pounds', 'FKP', '£', ',', '.'),
(40, 'Fiji', 'Dollars', 'FJD', '$', ',', '.'),
(41, 'France', 'Euro', 'EUR', '€', ',', '.'),
(42, 'Ghana', 'Cedis', 'GHC', '¢', ',', '.'),
(43, 'Gibraltar', 'Pounds', 'GIP', '£', ',', '.'),
(44, 'Greece', 'Euro', 'EUR', '€', ',', '.'),
(45, 'Guatemala', 'Quetzales', 'GTQ', 'Q', ',', '.'),
(46, 'Guernsey', 'Pounds', 'GGP', '£', ',', '.'),
(47, 'Guyana', 'Dollars', 'GYD', '$', ',', '.'),
(48, 'Holland (Netherlands)', 'Euro', 'EUR', '€', ',', '.'),
(49, 'Honduras', 'Lempiras', 'HNL', 'L', ',', '.'),
(50, 'Hong Kong', 'Dollars', 'HKD', '$', ',', '.'),
(51, 'Hungary', 'Forint', 'HUF', 'Ft', ',', '.'),
(52, 'Iceland', 'Kronur', 'ISK', 'kr', ',', '.'),
(53, 'India', 'Rupees', 'INR', '₹', ',', '.'),
(54, 'Indonesia', 'Rupiahs', 'IDR', 'Rp', ',', '.'),
(55, 'Iran', 'Rials', 'IRR', '﷼', ',', '.'),
(56, 'Ireland', 'Euro', 'EUR', '€', ',', '.'),
(57, 'Isle of Man', 'Pounds', 'IMP', '£', ',', '.'),
(58, 'Israel', 'New Shekels', 'ILS', '₪', ',', '.'),
(59, 'Italy', 'Euro', 'EUR', '€', ',', '.'),
(60, 'Jamaica', 'Dollars', 'JMD', 'J$', ',', '.'),
(61, 'Japan', 'Yen', 'JPY', '¥', ',', '.'),
(62, 'Jersey', 'Pounds', 'JEP', '£', ',', '.'),
(63, 'Kazakhstan', 'Tenge', 'KZT', 'лв', ',', '.'),
(64, 'Korea (North)', 'Won', 'KPW', '₩', ',', '.'),
(65, 'Korea (South)', 'Won', 'KRW', '₩', ',', '.'),
(66, 'Kyrgyzstan', 'Soms', 'KGS', 'лв', ',', '.'),
(67, 'Laos', 'Kips', 'LAK', '₭', ',', '.'),
(68, 'Latvia', 'Lati', 'LVL', 'Ls', ',', '.'),
(69, 'Lebanon', 'Pounds', 'LBP', '£', ',', '.'),
(70, 'Liberia', 'Dollars', 'LRD', '$', ',', '.'),
(71, 'Liechtenstein', 'Switzerland Francs', 'CHF', 'CHF', ',', '.'),
(72, 'Lithuania', 'Litai', 'LTL', 'Lt', ',', '.'),
(73, 'Luxembourg', 'Euro', 'EUR', '€', ',', '.'),
(74, 'Macedonia', 'Denars', 'MKD', 'ден', ',', '.'),
(75, 'Malaysia', 'Ringgits', 'MYR', 'RM', ',', '.'),
(76, 'Malta', 'Euro', 'EUR', '€', ',', '.'),
(77, 'Mauritius', 'Rupees', 'MUR', '₨', ',', '.'),
(78, 'Mexico', 'Pesos', 'MX', '$', ',', '.'),
(79, 'Mongolia', 'Tugriks', 'MNT', '₮', ',', '.'),
(80, 'Mozambique', 'Meticais', 'MZ', 'MT', ',', '.'),
(81, 'Namibia', 'Dollars', 'NAD', '$', ',', '.'),
(82, 'Nepal', 'Rupees', 'NPR', '₨', ',', '.'),
(83, 'Netherlands Antilles', 'Guilders', 'ANG', 'ƒ', ',', '.'),
(84, 'Netherlands', 'Euro', 'EUR', '€', ',', '.'),
(85, 'New Zealand', 'Dollars', 'NZD', '$', ',', '.'),
(86, 'Nicaragua', 'Cordobas', 'NIO', 'C$', ',', '.'),
(87, 'Nigeria', 'Nairas', 'NG', '₦', ',', '.'),
(88, 'North Korea', 'Won', 'KPW', '₩', ',', '.'),
(89, 'Norway', 'Krone', 'NOK', 'kr', ',', '.'),
(90, 'Oman', 'Rials', 'OMR', '﷼', ',', '.'),
(91, 'Pakistan', 'Rupees', 'PKR', '₨', ',', '.'),
(92, 'Panama', 'Balboa', 'PAB', 'B/.', ',', '.'),
(93, 'Paraguay', 'Guarani', 'PYG', 'Gs', ',', '.'),
(94, 'Peru', 'Nuevos Soles', 'PE', 'S/.', ',', '.'),
(95, 'Philippines', 'Pesos', 'PHP', 'Php', ',', '.'),
(96, 'Poland', 'Zlotych', 'PL', 'zł', ',', '.'),
(97, 'Qatar', 'Rials', 'QAR', '﷼', ',', '.'),
(98, 'Romania', 'New Lei', 'RO', 'lei', ',', '.'),
(99, 'Russia', 'Rubles', 'RUB', 'руб', ',', '.'),
(100, 'Saint Helena', 'Pounds', 'SHP', '£', ',', '.'),
(101, 'Saudi Arabia', 'Riyals', 'SAR', '﷼', ',', '.'),
(102, 'Serbia', 'Dinars', 'RSD', 'Дин.', ',', '.'),
(103, 'Seychelles', 'Rupees', 'SCR', '₨', ',', '.'),
(104, 'Singapore', 'Dollars', 'SGD', '$', ',', '.'),
(105, 'Slovenia', 'Euro', 'EUR', '€', ',', '.'),
(106, 'Solomon Islands', 'Dollars', 'SBD', '$', ',', '.'),
(107, 'Somalia', 'Shillings', 'SOS', 'S', ',', '.'),
(108, 'South Africa', 'Rand', 'ZAR', 'R', ',', '.'),
(109, 'South Korea', 'Won', 'KRW', '₩', ',', '.'),
(110, 'Spain', 'Euro', 'EUR', '€', ',', '.'),
(111, 'Sri Lanka', 'Rupees', 'LKR', '₨', ',', '.'),
(112, 'Sweden', 'Kronor', 'SEK', 'kr', ',', '.'),
(113, 'Switzerland', 'Francs', 'CHF', 'CHF', ',', '.'),
(114, 'Suriname', 'Dollars', 'SRD', '$', ',', '.'),
(115, 'Syria', 'Pounds', 'SYP', '£', ',', '.'),
(116, 'Taiwan', 'New Dollars', 'TWD', 'NT$', ',', '.'),
(117, 'Thailand', 'Baht', 'THB', '฿', ',', '.'),
(118, 'Trinidad and Tobago', 'Dollars', 'TTD', 'TT$', ',', '.'),
(119, 'Turkey', 'Lira', 'TRY', 'TL', ',', '.'),
(120, 'Turkey', 'Liras', 'TRL', '£', ',', '.'),
(121, 'Tuvalu', 'Dollars', 'TVD', '$', ',', '.'),
(122, 'Ukraine', 'Hryvnia', 'UAH', '₴', ',', '.'),
(123, 'United Kingdom', 'Pounds', 'GBP', '£', ',', '.'),
(124, 'United States of America', 'Dollars', 'USD', '$', ',', '.'),
(125, 'Uruguay', 'Pesos', 'UYU', '$U', ',', '.'),
(126, 'Uzbekistan', 'Sums', 'UZS', 'лв', ',', '.'),
(127, 'Vatican City', 'Euro', 'EUR', '€', ',', '.'),
(128, 'Venezuela', 'Bolivares Fuertes', 'VEF', 'Bs', ',', '.'),
(129, 'Vietnam', 'Dong', 'VND', '₫', ',', '.'),
(130, 'Yemen', 'Rials', 'YER', '﷼', ',', '.'),
(131, 'Zimbabwe', 'Zimbabwe Dollars', 'ZWD', 'Z$', ',', '.'),
(132, 'Bangladesh', 'Taka ', 'BDT', '৳', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--

CREATE TABLE IF NOT EXISTS `customer_order` (
  `auto_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(15) NOT NULL,
  `order_date` date NOT NULL,
  `order_month` varchar(5) NOT NULL,
  `order_get_from` varchar(50) NOT NULL,
  `customer_id` int(5) NOT NULL,
  `total_qty` int(3) NOT NULL,
  `discount` int(2) DEFAULT NULL,
  `service_tax` float(8,2) DEFAULT NULL,
  `total_paid` float(8,2) NOT NULL,
  `total_balance` float(8,2) NOT NULL,
  `pickup_by` varchar(75) NOT NULL,
  `pickup_date` varchar(15) NOT NULL,
  `delivery_by` varchar(75) NOT NULL,
  `delivery_date` varchar(15) DEFAULT NULL,
  `remarks` text NOT NULL,
  `amt_paidby` varchar(25) NOT NULL,
  `cheque_no` varchar(25) DEFAULT NULL,
  `cheque_date` varchar(25) DEFAULT NULL,
  `order_status` varchar(10) NOT NULL,
  PRIMARY KEY (`auto_id`),
  UNIQUE KEY `order_id` (`invoice_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `customer_order`
--

INSERT INTO `customer_order` (`auto_id`, `invoice_no`, `order_date`, `order_month`, `order_get_from`, `customer_id`, `total_qty`, `discount`, `service_tax`, `total_paid`, `total_balance`, `pickup_by`, `pickup_date`, `delivery_by`, `delivery_date`, `remarks`, `amt_paidby`, `cheque_no`, `cheque_date`, `order_status`) VALUES
(1, 'SC01', '2017-07-22', 'Jul', '', 1, 3, 0, 0.00, 25.00, 0.00, '', '', '', '', '', 'bycash', '', '22-07-2017', 'pending'),
(2, 'SC02', '2017-07-23', 'Jul', '', 1, 16, 10, 18.00, 181.80, 0.00, '2', '10-10-2017', '3', '18-10-2017', '', 'bycash', '', '23-07-2017', 'delivered'),
(3, 'SC03', '2017-07-27', 'Jul', 'admin', 1, 2, 0, 0.00, 10.00, 0.00, '', '', '', '15-08-2017', '', 'bycash', '', '', 'delivered'),
(4, 'SC04', '2017-07-31', 'Jul', 'admin', 1, 30, 0, 0.00, 150.00, 0.00, '', '', '', '11-08-2017', '', 'online', '', '', 'pending'),
(5, 'SC05', '2017-08-01', 'Aug', 'admin', 1, 6, 0, 0.00, 30.00, 0.00, '2', '10-08-2017', '2', '10-08-2017', '', 'bycash', '', '', 'delivered'),
(6, 'SC06', '2017-08-07', 'Aug', '', 3, 2, 0, 0.00, 10.00, 0.00, '2', '07-08-2017', '2', '08-08-2017', '', 'online', '', '', 'delivered'),
(7, 'SC07', '2017-08-10', 'Aug', 'admin', 5, 2, 0, 0.00, 10.00, 0.00, '2', '10-08-2017', '2', '10-08-2017', '', 'bycash', '', '', 'delivered'),
(8, 'SC08', '2017-08-10', 'Aug', 'admin', 2, 5, 0, 0.00, 40.00, 0.00, '', '', '', '31-08-2017', '', 'bycash', '654654', '27-08-2017', 'pending'),
(9, 'SC09', '2017-08-11', 'Aug', '', 6, 22, 0, 0.00, 135.00, 0.00, '1', '31-08-2017', '', '', '', 'online', '', '', 'pending'),
(10, 'SC010', '2017-08-15', 'Aug', '', 6, 34, 0, 0.00, 190.00, 0.00, '', '', '', '31-08-2017', '', 'bycash', '', '', 'pending'),
(11, 'SC011', '2017-08-15', 'Aug', '', 7, 5, NULL, NULL, 25.00, 0.00, '', '', '', NULL, 'Pickup', '', NULL, NULL, 'pending'),
(12, 'SC012', '2017-08-15', 'Aug', 'admin', 3, 12, 0, 0.00, 130.00, 0.00, '', '', '', '15-08-2017', 'yhh', '', '', '', 'pending'),
(13, 'SC013', '2017-08-18', 'Aug', 'admin', 6, 15, 0, 0.00, 5025.00, 0.00, '', '', '', '18-08-2017', 'Work starts', 'bycash', '', '', 'pending'),
(14, 'SC014', '2017-09-01', 'Sep', 'admin', 9, 3, 0, 0.00, 25.00, 0.00, '2', '31-08-2017', '2', '31-08-2017', '', 'bycash', '', '', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `join_date` varchar(15) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `emp_add1` varchar(150) NOT NULL,
  `emp_add2` varchar(100) NOT NULL,
  `emp_city` varchar(50) NOT NULL,
  `emp_state` varchar(50) NOT NULL,
  `emp_zip` varchar(10) NOT NULL,
  `birth_date` varchar(15) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `status` varchar(10) NOT NULL,
  `password` varchar(400) NOT NULL,
  `leave_date` varchar(15) NOT NULL,
  `last_login` varchar(50) NOT NULL,
  `salary` text NOT NULL,
  `designation` varchar(50) NOT NULL,
  `group_id` varchar(10) NOT NULL,
  `emp_role` varchar(100) NOT NULL,
  PRIMARY KEY (`emp_id`),
  UNIQUE KEY `mobile` (`mobile`),
  UNIQUE KEY `email_id` (`email_id`),
  UNIQUE KEY `password` (`password`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `join_date`, `first_name`, `last_name`, `mobile`, `email_id`, `emp_add1`, `emp_add2`, `emp_city`, `emp_state`, `emp_zip`, `birth_date`, `gender`, `status`, `password`, `leave_date`, `last_login`, `salary`, `designation`, `group_id`, `emp_role`) VALUES
(1, '18-07-2017', 'John', 'Bob', '123456789', '12@12.com', 'rtghtr', '3545', 'fdsg', '34', '234', '18-07-2017', 'male', 'enable', 'john', '', '', '', 'Employee', '1', ''),
(2, '26-07-2017', 'Akash', 'Demin', '9999999999', 'akash@gmail.com', 'kachi', 'kachi', 'kachi', 'state', '0000000', '26-07-1990', 'male', 'enable', '89e495e7941cf9e40e6980d14a16bf023ccd4c91', '', '', '', 'Delivery Man', '3', 'enable'),
(3, '01-10-2017', 'Ajit', 'Dhanwade', '8108702999', 'ajitrajyash@yahoo.com', 'B-02, Sai Sanklap CHS', 'usarli', 'Panvel', 'Maharashtra', '416308', '13-11-1983', 'male', 'enable', 'c6be180801da676d0cd525760c86a837f0efcc6e', '', '', '', 'Manager', '6', 'enable');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE IF NOT EXISTS `expenses` (
  `exp_id` int(11) NOT NULL AUTO_INCREMENT,
  `exps_date` varchar(15) NOT NULL,
  `exp_payee_name` varchar(100) NOT NULL,
  `exp_type` varchar(100) NOT NULL,
  `exp_amt` float(8,2) NOT NULL,
  `exp_paidby` varchar(10) NOT NULL,
  `exp_chequeno` varchar(20) NOT NULL,
  `exp_cheque_date` varchar(15) NOT NULL,
  `exp_remarks` text NOT NULL,
  PRIMARY KEY (`exp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`exp_id`, `exps_date`, `exp_payee_name`, `exp_type`, `exp_amt`, `exp_paidby`, `exp_chequeno`, `exp_cheque_date`, `exp_remarks`) VALUES
(1, '09-08-2017', 'Electricity Board', 'Electricity', 500.00, 'bycash', '', '', 'Paid Amount'),
(2, '11-08-2017', 'Ayoub Alismaili', 'Travelling', 50.00, 'bycash', '', '10-08-2017', 'Amt to delivery product'),
(3, '23-08-2017', 'Water', 'Water', 500.00, 'bycash', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `expense_type`
--

CREATE TABLE IF NOT EXISTS `expense_type` (
  `exps_id` int(11) NOT NULL AUTO_INCREMENT,
  `exps_type` varchar(100) NOT NULL,
  `exps_code` varchar(25) NOT NULL,
  PRIMARY KEY (`exps_id`),
  UNIQUE KEY `exps_type` (`exps_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `expense_type`
--

INSERT INTO `expense_type` (`exps_id`, `exps_type`, `exps_code`) VALUES
(1, 'Electricity', 'ELEC'),
(2, 'Travelling', 'TRAVEL'),
(3, 'Water', 'H2O');

-- --------------------------------------------------------

--
-- Table structure for table `mem_group`
--

CREATE TABLE IF NOT EXISTS `mem_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `group_permission` text NOT NULL,
  `group_status` varchar(50) NOT NULL,
  `group_descr` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_name` (`group_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `mem_group`
--

INSERT INTO `mem_group` (`id`, `group_name`, `group_permission`, `group_status`, `group_descr`) VALUES
(1, 'Administrator', 'a:6:{i:0;s:7:"desktop";i:1;s:6:"master";i:2;s:8:"joborder";i:3;s:7:"reports";i:4;s:8:"settings";i:5;s:12:"groupanduser";}', 'enable', 'Access all model (Desktop, Master, Service, etc)'),
(2, 'Users', 'a:5:{i:0;s:7:"desktop";i:1;s:6:"master";i:2;s:8:"joborder";i:3;s:7:"reports";i:4;s:8:"settings";}', 'enable', 'Access model (Desktop, Service, Group)'),
(3, 'Delivery_Boy', 'a:1:{i:0;s:4:"null";}', 'enable', 'No Any Access Model (only See Reports)'),
(6, 'Drivers', 'a:1:{i:0;s:4:"null";}', 'enable', 'No Any Access Model (only See Reports)'),
(7, 'Employee', 'a:1:{i:0;s:4:"null";}', 'enable', 'Access Model (Services, Job Order)');

-- --------------------------------------------------------

--
-- Table structure for table `order_temp`
--

CREATE TABLE IF NOT EXISTS `order_temp` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_date` varchar(15) NOT NULL,
  `customer_id` int(5) NOT NULL,
  `price_shortcode` text NOT NULL,
  `order_service` varchar(50) NOT NULL,
  `order_cloth` varchar(50) NOT NULL,
  `order_price` varchar(50) NOT NULL,
  `order_qty` int(2) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `order_temp`
--

INSERT INTO `order_temp` (`order_id`, `order_date`, `customer_id`, `price_shortcode`, `order_service`, `order_cloth`, `order_price`, `order_qty`) VALUES
(1, '2017-07-22', 1, '1', 'Washing', 'Shirts', '5.00', 1),
(2, '23-07-2017', 1, '3', 'Washing & Ironing', 'Shirts', '10.00', 2),
(3, '23-07-2017', 1, '2', 'Washing', 'Pants', '5.00', 2),
(4, '2017-07-22', 1, '4', 'Washing & Ironing', 'Pants', '10.00', 2),
(5, '2017-07-23', 1, '5', 'Ironing', 'Pants', '1', 4),
(6, '2017-07-23', 1, '1', 'Washing', 'Shirts', '5.00', 2),
(7, '2017-07-23', 1, '4', 'Washing & Ironing', 'Pants', '10.00', 5),
(8, '2017-07-27', 1, '1', 'Washing', 'Shirts', '5.00', 2),
(9, '2017-07-31', 1, '1', 'Washing', 'Shirts', '5.00', 10),
(10, '2017-07-31', 1, '1', 'Washing', 'Shirts', '5.00', 10),
(11, '2017-07-31', 1, '1', 'Washing', 'Shirts', '5.00', 10),
(12, '2017-08-01', 1, '1', 'Washing', 'Shirts', '5.00', 6),
(13, '2017-08-03', 2, '1', 'Washing', 'Shirts', '5.00', 2),
(14, '2017-08-07', 3, '1', 'Washing', 'Shirts', '5.00', 2),
(15, '2017-08-10', 5, '2', 'Washing', 'Pants', '5.00', 2),
(16, '2017-08-10', 2, '2', 'Washing', 'Pants', '5.00', 2),
(17, '2017-08-10', 2, '4', 'Washing & Ironing', 'Pants', '10.00', 3),
(18, '2017-08-11', 6, '1', 'Washing', 'Shirts', '5.00', 1),
(19, '2017-08-11', 6, '2', 'Washing', 'Pants', '5.00', 5),
(20, '2017-08-11', 6, '1', 'Washing', 'Shirts', '5.00', 11),
(21, '2017-08-11', 6, '4', 'Washing & Ironing', 'Pants', '10.00', 5),
(22, '2017-08-15', 6, '1', 'Washing', 'Shirts', '5.00', 1),
(23, '2017-08-15', 6, '3', 'Washing & Ironing', 'Shirts', '10.00', 2),
(24, '2017-08-15', 6, '5', 'Ironing', 'Pants', '15.00', 1),
(25, '2017-08-15', 7, '1', 'Washing', 'Shirts', '5.00', 5),
(26, '2017-08-15', 2, '6', 'Washing & Ironing', 'Pants', '500.00', 4),
(27, '2017-08-15', 6, '2', 'Washing', 'Pants', '5.00', 30),
(28, '2017-08-15', 3, '2', 'Washing', 'Pants', '5.00', 5),
(29, '2017-08-15', 3, '5', 'Ironing', 'Pants', '15.00', 7),
(30, '2017-08-18', 6, '1', 'Washing', 'Shirts', '5.00', 5),
(31, '2017-08-18', 6, '6', 'Washing & Ironing', 'Pants', '500.00', 10),
(32, '2017-08-19', 4, '1', 'Washing', 'Shirts', '5.00', 5),
(33, '2017-08-20', 3, '1', 'Washing', 'Shirts', '5.00', 1),
(34, '2017-08-31', 1, '1', 'Washing', 'Shirts', '5.00', 5),
(35, '2017-07-23', 1, '3', 'Washing & Ironing', 'Shirts', '10.00', 5),
(36, '2017-09-01', 9, '1', 'Washing', 'Shirts', '5.00', 1),
(37, '2017-09-01', 9, '4', 'Washing & Ironing', 'Pants', '10.00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `price_list`
--

CREATE TABLE IF NOT EXISTS `price_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` varchar(10) NOT NULL,
  `cloth_id` varchar(5) NOT NULL,
  `price` varchar(8) NOT NULL,
  `short_code` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_code` (`short_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `price_list`
--

INSERT INTO `price_list` (`id`, `service_id`, `cloth_id`, `price`, `short_code`) VALUES
(1, '1', '1', '5.00', 'W/S'),
(2, '1', '2', '5.00', 'W/P'),
(3, '3', '1', '10.00', 'WI/S'),
(4, '3', '2', '10.00', 'WI/P'),
(5, '2', '2', '15.00', 'TEST'),
(6, '3', '2', '500.00', 'PTS');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(100) NOT NULL,
  `service_code` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_name` (`service_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service_name`, `service_code`) VALUES
(1, 'Washing', 'W'),
(2, 'Ironing', 'I'),
(3, 'Washing & Ironing', 'WI');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(150) NOT NULL,
  `shop_add` text NOT NULL,
  `shop_add1` varchar(100) NOT NULL,
  `shop_add2` varchar(100) NOT NULL,
  `shop_city` varchar(50) NOT NULL,
  `shop_state` varchar(100) NOT NULL,
  `shop_zip` varchar(10) NOT NULL,
  `shop_gmap` text NOT NULL,
  `shop_phone` varchar(15) NOT NULL,
  `shop_mobile` varchar(10) NOT NULL,
  `shop_email` varchar(75) NOT NULL,
  `shop_logo` text NOT NULL,
  `sys_lang` varchar(50) NOT NULL,
  `sys_currency` varchar(50) CHARACTER SET utf8 NOT NULL,
  `sys_timezone` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shop_name` (`shop_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `shop_name`, `shop_add`, `shop_add1`, `shop_add2`, `shop_city`, `shop_state`, `shop_zip`, `shop_gmap`, `shop_phone`, `shop_mobile`, `shop_email`, `shop_logo`, `sys_lang`, `sys_currency`, `sys_timezone`) VALUES
(1, 'Red Planet Laundry ', 'B-02, Sai Sanklap Chs', 'B-02, Sai Sanklap CHS', 'Survey No. 145/0, Usarli Khurd', 'Panvel', 'Maharashtra', '410206', '18.980284994286844, 73.13549852666847', '8767228990', '8767228990', 'info@redplanetcomputers.com', '', '1', 'India', 'Asia/Kolkata');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `join_date` varchar(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `address2` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `country` varchar(100) NOT NULL,
  `cust_map_pos` text NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL,
  `password` varchar(100) NOT NULL,
  `last_login` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_id` (`email_id`),
  UNIQUE KEY `mobile` (`mobile`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `join_date`, `first_name`, `last_name`, `address1`, `address2`, `city`, `state`, `zipcode`, `country`, `cust_map_pos`, `email_id`, `phone`, `mobile`, `status`, `password`, `last_login`) VALUES
(1, '30-06-2017', 'Demo', 'Demo', 'B-02, Sai Sanklap CHS', 'Survey No. 145/0, Usarli Khurd', 'Panvel', 'Maharashtra', '410206', 'India', '18.98499660952764, 73.13225140268787', 'demo@demo.com', '', '1234567890', 'enable', 'demo', ''),
(2, '25-07-2017', 'Ayoub', 'Alismaili', '', '', '', '', '', '', '18.983003970140288, 73.13362098035805', 'ayoooo4b@gmail.com', '', '96747611', 'enable', 'demo', ''),
(3, '07-08-2017', 'Test', 'Test', '', '', '', '', '', '', '18.98139085176098, 73.13457584676735', 'kumarsyscomit@gmail.com', '', '33006970', 'enable', 'demo', ''),
(4, '09-08-2017', 'Gusti', 'Darma Yudha', '', '', '', '', '', '', '18.98139085176098, 73.13457584676735', 'gustidarmayudha@gmail.com', '', '081314446996', 'enable', 'demo', ''),
(5, '10-08-2017', 'Asif', 'Ahmed', 'Vertex Tower, Block D', 'Floor : 35 D, Flat#12A, Cyb', '', '', '', '', '18.98139085176098, 73.13457584676735', 'remoon@gmail.com', '', '+601121512776', 'enable', '46uu7', ''),
(6, '11-08-2017', 'Test', 'ABC', '', '', '', '', '', '', '19.02402670727833, 73.0968532591819', 'abc@abc.com', '', '01911111', 'enable', '12345', ''),
(7, '15-08-2017', 'Siddharth ', 'Chowke ', '', '', '', '', '', '', '18.983003970140288, 73.13364243803017', 'Peace4siddharth@gmail.com', '', '0544587649', 'enable', 'demo', ''),
(9, '01-09-2017', 'Renzo', 'Abrillo', 'Binangonan Rizal', '', 'Rizal', '', '1940', '', '18.980284994286844, 73.13549852666847', 'renzoabrillo16@yahoo.com', '', '0917 427 4518', 'enable', 'demo', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
