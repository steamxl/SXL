<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/*
	 *	@author 	: Ajit Dhanawade / 8108702999
	 *	date		: 07 June, 2017
	 *	Laundry Management Application (Login Model)
	 *	ajitrajyash@gmail.com
	*/
 
	public function __construct()
    {   parent::__construct();
        $this->load->helper(array('form','url','html','cookie'));
        $this->load->library(array('session', 'form_validation'));
        $this->load->database();
		$this->load->model('login_model');
      	$this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Sat, 11 Jun 1983 05:00:00 GMT");
		
    }
	
	public function index()
	{			
		$this->load->view('login');
	}
	
	public function rediract()
	{	// get form input
		$UserName=$this->input->post('username');
		$Password=$this->input->post('password');
		
		$uresult = $this->login_model->get_user($UserName, $Password);
		
		if (count($uresult) > 0)
		{	
			//echo "Login Successfully ==> Redirecting";
			$this->session->set_userdata('admin_login', 1);
			$this->session->set_userdata('user_from', $UserName);
			if ($this->session->userdata('admin_login') == 1)
			{ ?> <script> alert("Administration Login Successfully \nRedirecting Dashboard ..."); </script> <?php	
			redirect('admin/index','refresh');
			}
		}
		else		//Check Employee Login
		{	
			$mobile=$this->input->post('username');
			$pwd=sha1($this->input->post('password'));
			
			$this->db->where("email_id = '$mobile' OR mobile = '$mobile'");
			$this->db->where('password', $pwd);
			$empresult = $this->db->get('employee');
		
						
			if (count($empresult->result()) > 0)
			{	
					// Login Status Enable or Disable 
					
					$this->db->where("status='disable' AND (email_id = '$mobile' OR mobile = '$mobile')");
					
					$check = $this->db->get('employee');
				 
					if(count($check->result()) > 0)		// using direct parameter
					{
					?>
					<script> alert("Your account is Deactived \nPlease Contact Administrator (Check Login Status enable or disabled) "); </script>
					<?php
					redirect('../../admin','refresh');
					}

					// Employee Role (Driver or Delivery Boy ) 
					
					$this->db->where("emp_role='enable' AND (email_id = '$mobile' OR mobile = '$mobile')");
					
					$emppage = $this->db->get('employee');
				 
					if(count($emppage->result()) > 0)		// using direct parameter
					{	$this->session->set_userdata('employee_login', 1);
						if ($this->session->userdata('employee_login') == 1)
						{	
							foreach($empresult->result() as $getemprow): 
							$EmpId=$getemprow->emp_id;
							$this->session->set_userdata('emp_id',$EmpId);
							endforeach; 
					
						?> <script> alert("Hi, <?php echo $mobile; ?> Your Login Successfully \nRedirecting Dashboard ..."); </script> <?php	
						redirect('employee/index','refresh');
						}
					}
					
				
				$this->session->set_userdata('employee_login', 1);
				$this->session->set_userdata('admin_login', 1);
				if ($this->session->userdata('admin_login') == 1)
				{	
					foreach($empresult->result() as $getemprow): 
					$EmpId=$getemprow->emp_id;
					$GroupId=$getemprow->group_id;
					$this->session->set_userdata('emp_id',$EmpId);
					$this->session->set_userdata('group_id',$GroupId);
					endforeach; 
			
				?> <script> alert("Hi, <?php echo $mobile; ?> Your Login Successfully \nRedirecting Dashboard ..."); </script> <?php	
				redirect('admin/index','refresh');
				}
			}
			else
			{	$this->session->set_userdata('employee_login', 0);
				echo "<script> alert('Username and Password Invalid...'); </script>"; 	
				redirect('../../admin','refresh');
				
			}
		}


	}

	function logout() {
       	$this->session->set_userdata('admin_login', 0);
		$this->session->sess_destroy();
        $this->session->set_flashdata('logout_notification', 'logged_out');
		
		?>
			<script> alert("Your are Logging Out"); </script>
		<?php
		redirect('login/index','refresh');
    }
}
