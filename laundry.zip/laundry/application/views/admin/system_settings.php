<?php require_once("header.php"); ?>
<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="#">Settings</a>
							</li>

							<li>
								<a href="#">System</a> <?php echo "( " . date('j-M-Y h:i A') ." )"; ?>
							</li>
							
						</ul><!-- /.breadcrumb -->

						<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					
					
					<div class="page-content">
						<div class="page-header">
							<h1>
								System Settings 
								
							</h1>
						</div><!-- /.page-header -->

						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<div class="clearfix">
									

									
								</div>

								<?php foreach($sysdata->result() as $sysrow):    ?>
								
								<div class="">
										<form class="form-horizontal " id="user-form" method="post" action="<?php echo base_url();?>index.php/admin/systemset_update" enctype="multipart/form-data" >
										
																				
										<div class="form-group">
											<label class="col-sm-3 control-label no-padding-right" for="shop_name"> Shop Name : </label>

											<div class="col-sm-9">
												<input type="text" name="shop_name" id="shop_name" class="form-control"  value="<?php echo $sysrow->shop_name; ?>" autofocus/>
											</div>
										</div>
										
										<div class="form-group">
											<label class="col-sm-3 control-label no-padding-right" for="address1"> Address 1 : </label>

											<div class="col-sm-4">
												<input type="text" name="address1" id="address1" class="form-control" value="<?php echo $sysrow->shop_add1;?>" />
											</div>
										
											<label class="col-sm-1 control-label no-padding-right" for="address2"> Address 2 : </label>

											<div class="col-sm-4">
												<input type="text" name="address2" id="address2" class="form-control" value="<?php echo $sysrow->shop_add2;?>" />
											</div>
										</div>
										
										<div class="form-group">
											<label class="col-sm-3 control-label no-padding-right" for="city"> City : </label>

											<div class="col-sm-4">
												<input type="text" name="city" id="city" class="form-control"  value="<?php echo $sysrow->shop_city;?>" />
											</div>
										
											<label class="col-sm-1 control-label no-padding-right" for="state"> State : </label>

											<div class="col-sm-4">
												<input type="text" name="state" id="state" class="form-control" value="<?php echo $sysrow->shop_state;?>"  />
											</div>
										</div>
										
										<div class="form-group">
											<label class="col-sm-3 control-label no-padding-right" for="password">Address Map : </label>

											<div class="col-sm-4">
												<?php echo $sysmap['html']; ?>
												<input type="hidden" name="shop_gmap" id="shop_gmap" class="form-control" value="<?php echo $sysrow->shop_gmap; ?>"  />
											</div>
											
											<label class="col-sm-1 control-label no-padding-right" for="zipcode"> Zip Code : </label>

											<div class="col-sm-4">
												<input type="text" name="zipcode" id="zipcode" class="form-control" value="<?php echo $sysrow->shop_zip;?>"  />
											</div>
										</div>
										
										
										
																				
										
										<div class="form-group">
											<label class="col-sm-3 control-label no-padding-right" for="shop_phone"> Phone : </label>

											<div class="col-sm-9">
												<input type="text" name="shop_phone" id="shop_phone" class="form-control" value="<?php echo $sysrow->shop_phone; ?>" />
											</div>
										</div>
										
										<div class="form-group">
											<label class="col-sm-3 control-label no-padding-right" for="shop_mobile"> Mobile : </label>

											<div class="col-sm-9">
												<input type="text" name="shop_mobile" id="shop_mobile" class="form-control" value="<?php echo $sysrow->shop_mobile; ?>" />
											</div>
										</div>
										
										<div class="form-group">
											<label class="col-sm-3 control-label no-padding-right" for="shop_email"> Email ID : </label>

											<div class="col-sm-9">
												<input type="email" name="shop_email" id="shop_email" class="form-control"  value="<?php echo $sysrow->shop_email; ?>" />
											</div>
										</div>
										<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="shop_email"> </label>
										
										<div class="col-sm-9">
										
										</div>
										</div>
										<div class="form-group">
											
							
											<label class="col-sm-3 control-label no-padding-right" for="shop_logo"> Shop Logo( <img src='<?php echo base_url(); ?>assets/images/logo.png' style="height:30px; width:30px;"> )  : </label>

											<div class="col-sm-9">
												<input type="file" name="shop_logo" id="shop_logo" class="form-control" />
											</div>
										</div>
										
										
										
										<div class="hr dotted"></div>
										
										
										<div class="form-group">
											<label class="col-sm-3 control-label no-padding-right" for="timezone"> <span> System TimeZone : </span>  </label>

											<div class="col-sm-9">
												<select class="chosen-select form-control" name="timezone" id="timezone">
												<?php
												$timezones = DateTimeZone::listIdentifiers(DateTimeZone::ALL);

												foreach ($timezones as $timezone) {
													if($sysrow->sys_timezone==$timezone){ $sel="selected"; } else { $sel=""; }
														//echo "<option value='".$timezone."'".$sel." >". $timezone . "</option>";
														echo "<option value='".$timezone."'".$sel." >". str_replace('/', ' / ', $timezone) . "</option>";
														
												 }																			
												 ?>								
												</select>	
											
											</div>
										</div>
										
										<div class="form-group">
											<label class="col-sm-3 control-label no-padding-right" for="sys_lang"> <span> System Language : </span>  </label>

											<div class="col-sm-9">
												<select class="form-control" name="sys_lang" id="sys_lang">
													<option value="">-- Select --</option>
													<option value="1" selected>English(US)</option>
													<option value="2">English(UK)</option>
													<option value="3">Hindi</option>
													
												</select>
											
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label no-padding-right" for="sys_cur"> System Currency (<?php echo $sys_curr; ?>) : </label>

											<div class="col-sm-9">
												
												<select class="chosen-select form-control" name="sys_cur" id="sys_cur">
												<?php
												
												foreach ($world_curr->result() as $currencyrow) {
													if($sysrow->sys_currency==$currencyrow->country_name){ $selc="selected"; } else { $selc=""; }
														echo "<option value='".$currencyrow->country_name."'".$selc." >". $currencyrow->country_name . " ( " . $currencyrow->currency_symbol . " )</option>";
														
												 }																			
												 ?>								
												</select>	
											
											
											
												<!-- <input type="text" name="sys_cur" id="sys_cur" class="form-control" value="<?php echo $sysrow->sys_currency; ?>"/> -->
												<!-- <span style='font-size:10px;'> Note : <a href="http://www.xe.com/symbols.php" target="_blank" > Click Here </a> to List of Curreny Symbol (copy and Paste Here) </span> -->
											</div>
											
											
										</div>
										
										
										
										
										
										<div class="clearfix form-actions">
											<div class="col-md-offset-3 col-md-9">
												<input class="btn btn-success" type="submit" value=" &nbsp;&nbsp;&nbsp; Update &nbsp;&nbsp;&nbsp;">
													
													&nbsp; &nbsp; &nbsp;														
													&nbsp; &nbsp; &nbsp;
												<input class="btn" type="reset" value="&nbsp;&nbsp; Reset &nbsp;&nbsp; ">
													
												
											</div>
										</div>
										
										</form>
										<?php endforeach; ?> 
									</div>	
								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			
			

<?php require_once("footer.php"); ?>
	
		
<script type="text/javascript">						

function Profile(url)
	{
		// SHOWING AJAX PRELOADER IMAGE
		jQuery('#admin_profile .modal-body').html('<div style="text-align:center;margin-top:50px;"><img src="<?php echo base_url(); ?>/assets/preloader.gif" /></div>');
		
		// LOADING THE AJAX MODAL
		jQuery('#admin_profile').modal('show', {backdrop: 'true'});
		
		// SHOW AJAX RESPONSE ON REQUEST SUCCESS
		$.ajax({
			url: url,
			success: function(response)
			{
				jQuery('#admin_profile .modal-body').html(response);
			}
		});
	}
	</script>
    
    <!-- (Ajax Modal)-->
    <div class="modal fade" id="admin_profile">
        <div class="modal-dialog">
            <div class="modal-content">
                
                <div class="modal-header" style="background:#fbeed5;" >
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><?php echo "Edit Admin Profile "; ?></h4>
                </div>
                
                <div class="modal-body" style="height:500px; overflow:auto;">
                
                    
                    
                </div>
               <!-- 
                <div class="modal-footer" style="background:#fbeed5;">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
				-->
            </div>
        </div>
    </div>
	
		<!------------------>



		

<?php require_once("footer.php"); ?>

		

<script src="<?php echo base_url();?>assets/js/jquery-2.1.4.min.js"></script>

	<script type="text/javascript">
			if('ontouchstart' in document.documentElement) document.write("<script src='<?php echo base_url();?>assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
		</script>
		<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

		<!-- page specific plugin scripts -->
		<script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/jquery.dataTables.bootstrap.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/dataTables.buttons.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/buttons.flash.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/buttons.html5.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/buttons.print.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/buttons.colVis.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/buttons.pdf.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/buttons.pdf_font.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/dataTables.select.min.js"></script>
		
		
		<script src="<?php echo base_url();?>assets/js/jquery.ui.touch-punch.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/chosen.jquery.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/spinbox.min.js"></script>
		
		
		<!-- Form Validation -->
		<script src="<?php echo base_url();?>assets/js/jquery.validate.min.js"></script>
			
		<script src="<?php echo base_url();?>assets/js/jquery.knob.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/autosize.min.js"></script>
		
		<!-- ace scripts -->
		<script src="<?php echo base_url();?>assets/js/ace-elements.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/ace.min.js"></script>

		<!-- inline scripts related to this page -->
		<script type="text/javascript">
			jQuery(function($) {
				
				if(!ace.vars['touch']) {
					$('.chosen-select').chosen({allow_single_deselect:true}); 
					//resize the chosen on window resize
			
					$(window)
					.off('resize.chosen')
					.on('resize.chosen', function() {
						$('.chosen-select').each(function() {
							 var $this = $(this);
							 $this.next().css({'width': $this.parent().width()});
						})
					}).trigger('resize.chosen');
					//resize chosen on sidebar collapse/expand
					$(document).on('settings.ace.chosen', function(e, event_name, event_val) {
						if(event_name != 'sidebar_collapsed') return;
						$('.chosen-select').each(function() {
							 var $this = $(this);
							 $this.next().css({'width': $this.parent().width()});
						})
					});
			
			
					
				}
				
				
				
			})
		</script>
		<script type="text/javascript">
		function updateDatabase(newLat, newLng)
		{	alert("hi");
			// make an ajax request to a PHP file
			// on our site that will update the database
			// pass in our lat/lng as parameters
			$.post(
				"/admin/customer_crud/googlemapdb", 
				{ 'newLat': newLat, 'newLng': newLng, 'var1': 'value1' }
			)
			.done(function(data) {
				alert("Database updated");
			});
		}
	</script>
	<?php echo $sysmap['js']; ?>	
		
	</body>
</html>